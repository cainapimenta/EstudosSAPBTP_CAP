sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("treinamento.alfa.fornecedor.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);