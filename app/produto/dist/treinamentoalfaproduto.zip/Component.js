sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("treinamento.alfa.produto.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map